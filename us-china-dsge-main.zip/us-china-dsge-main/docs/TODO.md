# TODO

- [ ] Add `run_main.m` that runs the baseline model and exports IRFs to `figs/`
- [ ] Create `data/README.md` with source links (FRED/IMF/BIS) and series IDs
- [ ] Add short methods note and variable glossary in `docs/`
- [ ] Save initial IRFs (PNG/CSV) in `figs/` and add short notes in `docs/IRF_Notes.md`
- [ ] Update `README.md` with MATLAB/Dynare versions and Quick Start steps
